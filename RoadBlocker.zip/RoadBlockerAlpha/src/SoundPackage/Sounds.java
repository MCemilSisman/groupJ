package SoundPackage;

public class Sounds 
{         
    String mouseSoundAddress = "resources//clickSound.mp3";
    String collisionSoundAddress = "resources//collisionSound.mp3";
    String gameMusicAddress = "resources//backgroundMusic.mp3";
}