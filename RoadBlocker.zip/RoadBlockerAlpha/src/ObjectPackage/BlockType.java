package ObjectPackage;

public enum BlockType {
	BLOCK, FILLED, EMPTY, RED, SPACE, MARKED;
}
